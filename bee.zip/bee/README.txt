The photos are created by Dennis Sakva (https://twitter.com/DennisSakva), who generously allow us to use them for kornia tutorials.
